package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;

public interface IUserBankService {
	 public int login(String userid,String password) throws OnlineBankingException;
	 public int changeInCommunicationAddress(String userid) throws OnlineBankingException;
	 public int changeInCommunicationAddress(String userid,String addr,String number) throws OnlineBankingException;
	 public int  chequeBookRequest(String userid,String desc) throws OnlineBankingException;
	 public String trackServiceRequest(BankUser bu2) throws OnlineBankingException;
	 public int  fundTransfer(String userid,BankUser bu1,BankAdmin au) throws OnlineBankingException;
	 public int changePassword(String newpassword,String userid) throws OnlineBankingException;
	 public abstract ArrayList<BankUser> viewMiniStatement(String userid,int tranDuration) throws OnlineBankingException;
}
