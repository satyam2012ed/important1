package com.capg.project.service;

import java.util.ArrayList;

import com.capg.project.bankexception.OnlineBankingException;
import com.capg.project.bean.BankAdmin;
import com.capg.project.bean.BankUser;
import com.capg.project.dao.AdminBankDAOImpl;
import com.capg.project.dao.IAdminBankDAO;

public class AdminBankServiceImpl implements IAdminBankService {

	IAdminBankDAO admindao=new AdminBankDAOImpl();
	@Override
	public int createNewAccount(BankAdmin au) throws OnlineBankingException {
		return admindao.createNewAccount(au);
	}
	@Override
	public ArrayList<BankUser> viewTransaction(int account_id, int tranDuration)
			throws OnlineBankingException {
		
		return admindao.viewTransaction(account_id,tranDuration);
	}



}
